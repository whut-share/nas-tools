<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
	<title>seckiller&#39;s profile :: JPopsuki 2.0</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<link rel="shortcut icon" href="favicon.ico" />
	<link rel="search" type="application/opensearchdescription+xml" title="JPopsuki 2.0 - Torrents" href="/opensearch_torrents.xml" />
	<link rel="search" type="application/opensearchdescription+xml" title="JPopsuki 2.0 - Requests" href="/opensearch_requests.xml" />
	<link rel="search" type="application/opensearchdescription+xml" title="JPopsuki 2.0 - Forums" href="/opensearch_forums.xml" />
	<link rel="search" type="application/opensearchdescription+xml" title="JPopsuki 2.0 - Log" href="/opensearch_log.xml" />
	<link rel="search" type="application/opensearchdescription+xml" title="JPopsuki 2.0 - Users" href="/opensearch_users.xml" />
	<link rel="alternate" type="application/rss+xml" href="/feeds.php?feed=torrents_notify_ab9c80b6ae3c9c0f9a7cfd3c610f079e&amp;user=221569&amp;auth=0141da877fa1aa0858f8284253e2b3a0&amp;passkey=ab9c80b6ae3c9c0f9a7cfd3c610f079e&amp;authkey=3db1b57c9924f2764e6a78b524b6e48d" title="JPopsuki 2.0 - P.T.N." />
	<link rel="alternate" type="application/rss+xml" href="/feeds.php?feed=torrents_all&amp;user=221569&amp;auth=0141da877fa1aa0858f8284253e2b3a0&amp;passkey=ab9c80b6ae3c9c0f9a7cfd3c610f079e&amp;authkey=3db1b57c9924f2764e6a78b524b6e48d" title="JPopsuki 2.0 - All Torrents" />
	<link rel="alternate" type="application/rss+xml" href="/feeds.php?feed=torrents_album&amp;user=221569&amp;auth=0141da877fa1aa0858f8284253e2b3a0&amp;passkey=ab9c80b6ae3c9c0f9a7cfd3c610f079e&amp;authkey=3db1b57c9924f2764e6a78b524b6e48d" title="JPopsuki 2.0 - Album Torrents" />
	<link rel="alternate" type="application/rss+xml" href="/feeds.php?feed=torrents_single&amp;user=221569&amp;auth=0141da877fa1aa0858f8284253e2b3a0&amp;passkey=ab9c80b6ae3c9c0f9a7cfd3c610f079e&amp;authkey=3db1b57c9924f2764e6a78b524b6e48d" title="JPopsuki 2.0 - Single Torrents" />
	<link rel="alternate" type="application/rss+xml" href="/feeds.php?feed=torrents_pv&amp;user=221569&amp;auth=0141da877fa1aa0858f8284253e2b3a0&amp;passkey=ab9c80b6ae3c9c0f9a7cfd3c610f079e&amp;authkey=3db1b57c9924f2764e6a78b524b6e48d" title="JPopsuki 2.0 - PV Torrents" />
	<link rel="alternate" type="application/rss+xml" href="/feeds.php?feed=torrents_dvd&amp;user=221569&amp;auth=0141da877fa1aa0858f8284253e2b3a0&amp;passkey=ab9c80b6ae3c9c0f9a7cfd3c610f079e&amp;authkey=3db1b57c9924f2764e6a78b524b6e48d" title="JPopsuki 2.0 - DVD Torrents" />
	<link rel="alternate" type="application/rss+xml" href="/feeds.php?feed=torrents_tv-music&amp;user=221569&amp;auth=0141da877fa1aa0858f8284253e2b3a0&amp;passkey=ab9c80b6ae3c9c0f9a7cfd3c610f079e&amp;authkey=3db1b57c9924f2764e6a78b524b6e48d" title="JPopsuki 2.0 - TV-Music Torrents" />
	<link rel="alternate" type="application/rss+xml" href="/feeds.php?feed=torrents_tv-variety&amp;user=221569&amp;auth=0141da877fa1aa0858f8284253e2b3a0&amp;passkey=ab9c80b6ae3c9c0f9a7cfd3c610f079e&amp;authkey=3db1b57c9924f2764e6a78b524b6e48d" title="JPopsuki 2.0 - TV-Variety Torrents" />
	<link rel="alternate" type="application/rss+xml" href="/feeds.php?feed=torrents_tv-drama&amp;user=221569&amp;auth=0141da877fa1aa0858f8284253e2b3a0&amp;passkey=ab9c80b6ae3c9c0f9a7cfd3c610f079e&amp;authkey=3db1b57c9924f2764e6a78b524b6e48d" title="JPopsuki 2.0 - TV-Drama Torrents" />
	<link rel="alternate" type="application/rss+xml" href="/feeds.php?feed=torrents_fansubs&amp;user=221569&amp;auth=0141da877fa1aa0858f8284253e2b3a0&amp;passkey=ab9c80b6ae3c9c0f9a7cfd3c610f079e&amp;authkey=3db1b57c9924f2764e6a78b524b6e48d" title="JPopsuki 2.0 - Fansubs Torrents" />
	<link rel="alternate" type="application/rss+xml" href="/feeds.php?feed=torrents_pictures&amp;user=221569&amp;auth=0141da877fa1aa0858f8284253e2b3a0&amp;passkey=ab9c80b6ae3c9c0f9a7cfd3c610f079e&amp;authkey=3db1b57c9924f2764e6a78b524b6e48d" title="JPopsuki 2.0 - Pictures Torrents" />
	<link rel="alternate" type="application/rss+xml" href="/feeds.php?feed=torrents_misc&amp;user=221569&amp;auth=0141da877fa1aa0858f8284253e2b3a0&amp;passkey=ab9c80b6ae3c9c0f9a7cfd3c610f079e&amp;authkey=3db1b57c9924f2764e6a78b524b6e48d" title="JPopsuki 2.0 - Misc Torrents" />
	<link rel="alternate" type="application/rss+xml" href="/feeds.php?feed=torrents_lossless&amp;user=221569&amp;auth=0141da877fa1aa0858f8284253e2b3a0&amp;passkey=ab9c80b6ae3c9c0f9a7cfd3c610f079e&amp;authkey=3db1b57c9924f2764e6a78b524b6e48d" title="JPopsuki 2.0 - Lossless Torrents" />
	<link rel="alternate" type="application/rss+xml" href="/feeds.php?feed=torrents_flac&amp;user=221569&amp;auth=0141da877fa1aa0858f8284253e2b3a0&amp;passkey=ab9c80b6ae3c9c0f9a7cfd3c610f079e&amp;authkey=3db1b57c9924f2764e6a78b524b6e48d" title="JPopsuki 2.0 - FLAC Torrents" />
	<link href="static/styles/layer_cake/style.css" title="layer_cake" rel="stylesheet" type="text/css" media="screen" />
	<link href="static/styles/log.css" rel="stylesheet" type="text/css" />
	<link href="static/styles/global.css" rel="stylesheet" type="text/css" />
	<script src="static/functions/jquery.js" type="text/javascript"></script>
	<script src="static/functions/main.js" type="text/javascript"></script>
	<link rel="stylesheet" type="text/css" href="static/shadowbox-3.0.3/shadowbox.css">
	<script type="text/javascript" src="static/shadowbox-3.0.3/shadowbox.js"></script>
	<script type="text/javascript">
	Shadowbox.init();
	</script>
	<script type="text/javascript">
		function bluehorse()
		{
			if(confirm('Would you like to see a penis?')) {
				alert('Sick bastard. Oh well, here\'s a penis');
			} else {
				alert('Too bad! You\'re going to see one anyways');
			}

			document.location = "http://jpopsuki.eu/static/images/users/774/KICRK.png";
		}

		function penis()
		{
			document.cookie = 'invasion=zombie_fruits; expires=Fri, 04 Mar 2011 21:29:16 GMT; path=/';
			$('#randomfitta').css('display', 'none');
		}
	</script>


</head>
<body id="user">
<a name="top"></a>

<div id="wrapper">
<h1 class="hidden">JPopsuki 2.0</h1>

<div id="header">
	<div id="logo"><a href="index.php"></a></div>
	<div id="userinfo">
		<ul id="userinfo_username">
			<li><a href="user.php?id=221569" class="username">seckiller</a></li>
			<li class="brackets"><a href="user.php?action=edit&amp;userid=221569">Edit</a></li>
			<li class="brackets"><a href="logout.php?auth=3db1b57c9924f2764e6a78b524b6e48d">Logout</a></li>
		</ul>
		<ul id="userinfo_major">
			<li class="brackets"><strong><a href="upload.php">Upload</a></strong></li>
			<li class="brackets"><strong><a href="user.php?action=invite">Invite (2)</a></strong></li>
			<li class="brackets"><strong><a href="donate.php">Donate</a></strong></li>
		</ul>
		<ul id="userinfo_stats">
			<li>Up: <span class="stat">18.50 GB</span></li>
			<li>Down: <span class="stat">5.81 GB</span></li>
			<li>Ratio: <span class="stat"><span class="r20">3.19</span></span></li>
			<li><i><a href="bonus.php">Bonus: <span class="stat">8827</span></a></i></li>
		</ul>
		<ul id="userinfo_minor">
			<li><a href="inbox.php">Inbox</a></li>
			<li><a href="notice.php">Notices</a></li>
			<li><a href="torrents.php?type=uploaded&amp;userid=221569">Uploads</a></li>
			<li><a href="bookmarks.php">Bookmarks</a></li>
</a></li>
			<li><a href="user.php?action=notify">Notifications</a></li>
			<li><a href="userhistory.php?action=posts&amp;userid=221569">Posts</a></li>
			<li><a href="friends.php">Friends</a></li>
		</ul>
	</div>
	<div id="menu">
		<h4 class="hidden">Site Menu</h4>
		<ul>
			<li id="nav_index"><a href="index.php">Home</a></li>
			<li id="nav_torrents"><a href="torrents.php">Torrents</a></li>
			<li id="nav_artists"><a href="artist.php">Artists</a></li>
			<li id="nav_requests"><a href="requests.php">Requests</a></li>
                        <li id="nav_collages"><a href="collages.php">Collages</a></li>
			<li id="nav_forums"><a href="forums.php">Forums</a></li>
			<li id="nav_top10"><a href="top10.php">Top 10</a></li>
			<li id="nav_irc"><a href="irc.php">IRC</a></li>
			<li id="nav_tv"><a href="streaming.php">Radio</a></li>
			<li id="nav_rules"><a href="rules.php">Rules</a></li>
			<li id="nav_kb"><a href="kb2.php">Help</a></li>
			<li id="nav_staff"><a href="staff.php">Staff</a></li>
		</ul>
	</div>
	<div id="alerts">
        <div class="alertbar">
            <a href="notice.php">You have 1 new notice</a>
        </div>
	</div>
	<div id="searchbars">
		<ul>
 
			<li>
				<span class="hidden">Torrents: </span>
				<form action="torrents.php" method="get">
					<input
						onfocus="if (this.value == 'Torrents') this.value='';"
						onblur="if (this.value == '') this.value='Torrents';"
						value="Torrents" type="text" name="searchstr" size="17"
					/>
					<input value="Search" type="submit" class="hidden" />
				</form>
			</li>
 
 
			<li>
				<span class="hidden">Artist: </span>
				<form action="artist.php" method="get">
					<input
						onfocus="if (this.value == 'Artist') this.value='';"
						onblur="if (this.value == '') this.value='Artist';"
						value="Artist" type="text" name="name" size="17"
					/>
					<input value="Search" type="submit" class="hidden" />
				</form>
			</li>
 
			<li>
				<span class="hidden">Requests: </span>
				<form action="requests.php" method="get">
					<input
						onfocus="if (this.value == 'Requests') this.value='';"
						onblur="if (this.value == '') this.value='Requests';"
						value="Requests" type="text" name="search" size="17"
					/>
					<input value="Search" type="submit" class="hidden" />
				</form>
			</li>
			<li>
				<span class="hidden">Forums: </span>
				<form action="forums.php" method="get">
					<input value="search" type="hidden" name="action" />
					<input
						onfocus="if (this.value == 'Forums') this.value='';"
						onblur="if (this.value == '') this.value='Forums';"
						value="Forums" type="text" name="search" size="17"
					/>
					<input value="Search" type="submit" class="hidden" />
				</form>
			</li>
			<li>
				<span class="hidden">Log: </span>
				<form action="log.php" method="get">
					<input
						onfocus="if (this.value == 'Log') this.value='';"
						onblur="if (this.value == '') this.value='Log';"
						value="Log" type="text" name="search" size="17"
					/>
					<input value="Search" type="submit" class="hidden" />
				</form>
			</li>
			<li>
				<span class="hidden">Users: </span>
				<form action="user.php" method="get">
					<input type="hidden" name="action" value="search" />
					<input
						onfocus="if (this.value == 'Peeps') this.value='';"
						onblur="if (this.value == '') this.value='Peeps';"
						value="Peeps" type="text" name="username" size="17"
					/>
					<input value="Search" type="submit" class="hidden" />
				</form>
			</li>
		</ul>
	</div>

</div>
<br />
<div id="content">
<div class="thin">
	<h2>seckiller</h2>
	<div style="float: right">	<a href="/feeds.php?feed=useruploadfeed&amp;user_id=221569&amp;username=seckiller&amp;user=221569&amp;auth=0141da877fa1aa0858f8284253e2b3a0&amp;passkey=ab9c80b6ae3c9c0f9a7cfd3c610f079e&amp;authkey=3db1b57c9924f2764e6a78b524b6e48d">
	<img width="15" height="15" src="static/common/symbols/rss.png" alt="RSS" /></a></div>	<div class="sidebar">
		<div class="box" style="display: none">
			<div class="head colhead_dark">Options</div>
			<ul class="stats nobullet">
			</ul>
		</div>
		<div class="box">
			<div class="head colhead_dark">Stats</div>
			<ul class="stats nobullet">
				<li>Joined: <span title="May 22 2022, 08:23">4 weeks, 5 hours ago</span></li>
				<li>Last Seen: <span title="Jun 19 2022, 11:43">2 hours and 6 minutes ago</span></li>
				<li>Uploaded: 18.50 GB</li>
				<li>Downloaded: 5.81 GB</li>
				<li>Ratio: <span class="r20">3.19</span></li>
				<li>Bonus Points: 8827</li>
				<li>Bonus Points per Hour/Day: 23/574</li>
			</ul>
		</div>
		<div class="box">
			<div class="head colhead_dark">Ranks (percentile)</div>
			<ul class="stats nobullet">
				<li>Data uploaded: 51</li>
				<li>Data downloaded: 37</li>
				<li>Torrents uploaded: 0</li>
				<li>Requests filled: 0</li>
				<li>Posts made: 0</li>
				<li><strong>Overall rank: 21</strong></li>
			</ul>
		</div>
		<div class="box">
			<div class="head colhead_dark">Personal</div>
			<ul class="stats nobullet">
				<li>Class: Member</li>
				<li>Paranoia Level: 0</li>
				<li>Email: <a href="mailto:johnzp1109@gmail.com">johnzp1109@gmail.com</a>
				</li>
				<li>Passkey: ab9c80b6ae3c9c0f9a7cfd3c610f079e</li>
                                <li>Bailed Out By: <i>Nobody</i></li>

			</ul>
		</div>
		<div class="box">
			<div class="head colhead_dark">Community</div>
			<ul class="stats nobullet">
                    <li>Forum Posts: 0 [<a href="userhistory.php?action=posts&amp;userid=221569" title="View">View</a>]</li>
                    <li>Torrent Comments: 0 [<a href="userhistory.php?action=comments&amp;userid=221569" title="View">View</a>]</li>
                    <li>Requests filled: 0 for 0.00 B [<a href="requests.php?type=filled&amp;userid=221569" title="View">View</a>]</li>
				<li>Uploaded: 0 [<a href="torrents.php?type=uploaded&amp;userid=221569" title="View">View</a>] [<a href="torrents.php?action=redownload&amp;type=uploads&amp;userid=221569" onclick="return confirm('If you no longer have the content, your ratio WILL be affected, be sure to check the size of all albums before redownloading.');">Download</a>]</li>
				<li>Uploads Snatches: 0</li>
				<li>Seeding: 319 [<a href="torrents.php?type=seeding&amp;userid=221569" title="View">View</a>] [<a href="torrents.php?action=redownload&amp;type=seeding&amp;userid=221569" onclick="return confirm('If you no longer have the content, your ratio WILL be affected, be sure to check the size of all albums before redownloading.');">Download</a>]</li>
				<li>Leeching: 0 [<a href="torrents.php?type=leeching&amp;userid=221569" title="View">View</a>]</li>
				<li>Snatched: 329 [<a href="torrents.php?type=snatched&amp;userid=221569" title="View">View</a>]  [<a href="torrents.php?action=redownload&amp;type=snatches&amp;userid=221569" onclick="return confirm('If you no longer have the content, your ratio WILL be affected, be sure to check the size of all albums before redownloading.');">Download</a>]</li>
				<li>Invited: 0</li>
			</ul>
		</div>
			</div>
        <div class="main_column" style="width:580px">
		<div class="box">
			<div class="head">
				Profile				<span style="float:right;"></span>
			</div>
			<div class="pad">
				This profile is currently empty.			</div>
		</div>
	<table cellpadding="0" cellspacing="0" border="0">
		<tr class="colhead">
			<td colspan="5">Recent Snatches</td>
		<tr>
		<tr>
			<td>
				<a href="torrents.php?id=320680" title="YOASOBI - THE BOOK">
				<img src="static/images/torrents/320680.th.jpg" alt="YOASOBI - THE BOOK" width="105" /></a>
			</td>
			<td>
				<a href="torrents.php?id=200235" title="Thao Trang - Dancing Queen">
				<img src="static/images/torrents/200235.th.jpg" alt="Thao Trang - Dancing Queen" width="105" /></a>
			</td>
			<td>
				<a href="torrents.php?id=56207" title="Dream - DRM - Tasty">
				<img src="static/images/torrents/56207.th.jpg" alt="Dream - DRM - Tasty" width="105" /></a>
			</td>
			<td>
				<a href="torrents.php?id=216567" title="PIKOTARO - PPAP (Pen-Pineapple-Apple-Pen) [Instrumental]">
				<img src="static/images/torrents/216567.th.jpg" alt="PIKOTARO - PPAP (Pen-Pineapple-Apple-Pen) [Instrumental]" width="105" /></a>
			</td>
			<td>
				<a href="torrents.php?id=99811" title="hitomi - Fight for Your Run">
				<img src="static/images/torrents/99811.th.jpg" alt="hitomi - Fight for Your Run" width="105" /></a>
			</td>
		</tr>
	</table>
	<table cellpadding="6" cellspacing="1" border="0" class="border" width="100%" id="requests">
	<tr class="colhead_dark">
		<td style="width:48%;">
			<a href="requests.php?order=name&amp;sort=asc&search=&tag=&tags="><strong>Request Name</strong></a>
		</td>
		<td class="nobr"><strong>
Vote		</strong></td>
		<td>
			<a href="requests.php?order=bounty&amp;sort=desc&search=&tag=&tags="><strong>Bounty</strong></a>
		</td>
		<td>
			<a href="requests.php?order=id&amp;sort=desc&search=&tag=&tags="><strong>Requested On</strong></a>
		</td>
	</tr>

<tr class="datatable_rowb nobr"><td colspan="7">Nothing found!</td></tr>	</table>

	</div>
</div>
</div>
<div id="footer">
	<p>Site and design &copy; 2022 JPopsuki 2.0</p>
	<p>This page was created in 0.16006 second(s) on <span title="Just now">Jun 19 2022, 13:50</span></p>
	<p>

		<a href="http://en.wikipedia.org/wiki/Load_(computing)" target="_blank">Load average</a>:
		0.18, 0.53, 0.50		<br />
		(Average over 1 minute, 5 minutes and 15 minutes
 on 8 cores. Load is spiked by <a href="http://en.wikipedia.org/wiki/Cron" target="_blank">cron</a> every 15 minutes.)
	</p>
	<p>Powered by <a href="http://jpopsuki.eu/static/images/users/774/503x.jpg">Small Horse</a></p>
<!--	<script type="text/javascript" src="https://widgets.amung.us/colored.js"></script><script type="text/javascript">WAU_colored('l8tchbw95e38', 'e3f4fd000000')</script> -->
	<script type="text/javascript" src="https://widgets.amung.us/pro.js"></script>
	<script type="text/javascript" id="wau_scr_30b716e2">
    	wau_add('d0t8', '30b716e2')
	</script>
	<noscript>
    		<img src="https://whos.amung.us/piwidget/d0t8/" />
	</noscript> 

</div>

</div>
<div id="lightbox" class="lightbox"></div>
<div id="curtain" class="curtain"></div>

<!-- Extra divs, for stylesheet developers to add imagery -->
<div id="extra1"><span></span></div>
<div id="extra2"><span></span></div>
<div id="extra3"><span></span></div>
<div id="extra4"><span></span></div>
<div id="extra5"><span></span></div>
<div id="extra6"><span></span></div>
</body>
</html>
