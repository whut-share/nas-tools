<!DOCTYPE>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<meta name="keywords" content="BTSCHOOL,电影,学习,高校,高清,音乐" />
<meta name="description" content="BTSCHOOL小乐园" />
<meta name="generator" content="NexusPHP" />
<title>BTSCHOOL :: 用户详情 - seckiller 比特校园PT小乐园 - Powered by NexusPHP</title>
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon" />
<link rel="search" type="application/opensearchdescription+xml" title="BTSCHOOL Torrents" href="opensearch.php" />
<link rel="stylesheet" href="styles/mediumfont.css" type="text/css" />
<link rel="stylesheet" href="styles/sprites.css" type="text/css" />
<link rel="stylesheet" href="pic/forum_pic/chs/forumsprites.css" type="text/css" />
<link rel="stylesheet" href="styles/BlueGene/theme.css" type="text/css" />
<link rel="stylesheet" href="styles/BlueGene/DomTT.css" type="text/css" />
<link rel="stylesheet" href="styles/curtain_imageresizer.css" type="text/css" />
<link rel="stylesheet" href="pic/category/chd/scenetorrents/catsprites.css" type="text/css" />
<link rel="alternate" type="application/rss+xml" title="Latest Torrents" href="torrentrss.php" />
<script type="4a7d0149efcf75f7d8c0936c-text/javascript" src="curtain_imageresizer.js"></script>
<script type="4a7d0149efcf75f7d8c0936c-text/javascript" src="ajaxbasic.js"></script>
<script type="4a7d0149efcf75f7d8c0936c-text/javascript" src="common.js"></script>
<script type="4a7d0149efcf75f7d8c0936c-text/javascript" src="domLib.js"></script>
<script type="4a7d0149efcf75f7d8c0936c-text/javascript" src="domTT.js"></script>
<script type="4a7d0149efcf75f7d8c0936c-text/javascript" src="domTT_drag.js"></script>
<script type="4a7d0149efcf75f7d8c0936c-text/javascript" src="fadomatic.js"></script>
</head>
<body>
<table class="head" cellspacing="0" cellpadding="0" align="center">
<tr>
<td class="clear">
<div class="logo">BTSCHOOL</div>
<div class="slogan">汇聚每一个人的影响力</div>
</td>
<td class="clear nowrap" align="right" valign="middle">
<a href="donate.php"><img src="pic/forum_pic/chs/donate.gif" alt="Make a donation" style="margin-left: 5px; margin-top: 50px;" /></a>
</td>
</tr>
</table>
<table class="mainouter" width="982" cellspacing="0" cellpadding="5" align="center">
<tr><td id="nav_block" class="text" align="center">
<table class="main" width="940" border="0" cellspacing="0" cellpadding="0"><tr><td class="embedded"><div id="nav"><ul id="mainmenu" class="menu"><li><a href="index.php">&nbsp;首&nbsp;&nbsp;页&nbsp;</a></li><li><a href="forums.php">&nbsp;论&nbsp;&nbsp;坛&nbsp;</a></li><li><a href="torrents.php">&nbsp;种&nbsp;&nbsp;子&nbsp;</a></li><li><a href="offers.php">&nbsp;候&nbsp;&nbsp;选&nbsp;</a></li><li><a href="upload.php">&nbsp;发&nbsp;&nbsp;布&nbsp;</a></li><li><a href="subtitles.php">&nbsp;字&nbsp;&nbsp;幕&nbsp;</a></li><li><a href="usercp.php">&nbsp;控制面板&nbsp;</a></li><li><a href="topten.php">排&nbsp;行&nbsp;榜</a></li><li><a href="log.php">&nbsp;日&nbsp;&nbsp;志&nbsp;</a></li><li><a href="rules.php">&nbsp;规&nbsp;&nbsp;则&nbsp;</a></li><li><a href="faq.php">&nbsp;常见问题&nbsp;</a></li><li><a href="staff.php">管&nbsp;理&nbsp;组</a></li><li><a href="contactstaff.php">&nbsp;联系管理组&nbsp;</a></li></ul></div></td></tr></table>
<table id="info_block" cellpadding="4" cellspacing="0" border="0" width="100%"><tr>
<td><table width="100%" cellspacing="0" cellpadding="0" border="0"><tr>
<td class="bottom" align="left"><span class="medium">欢迎回来, <span class="nowrap"><a href="userdetails.php?id=97597" class='PowerUser_Name'><b>seckiller</b></a><img class="warned" src="pic/trans.gif" alt="Warned" style='margin-left: 2pt' /></span> [<a href="logout.php">退出</a>] [<a href="torrents.php?inclbookmarked=1&amp;allsec=1&amp;incldead=0">收藏</a>]&nbsp;[<a href="viewclaims.php">种子认领</a>]&nbsp;<font class="color_bonus">魔力值 </font>[<a href="mybonus.php">使用</a>]: 120,718.6 <font class="color_invite">邀请 </font>[<a href="invite.php?id=97597">发送</a>]: 1<br />
<font class="color_ratio">分享率：</font> 38.980 <a href="myhr.php"><font class='color_bonus'>&nbsp;&nbsp;H&amp;R:</font>0/<span style="color:#f00;font-weight: bold;">0</span></a>
<font class='color_uploaded'>上传量：</font> 10.636 TB<font class='color_downloaded'> 下载量：</font> 279.42 GB <font class='color_active'>当前活动：</font> <img class="arrowup" alt="Torrents seeding" title="当前做种" src="pic/trans.gif" />252 <img class="arrowdown" alt="Torrents leeching" title="当前下载" src="pic/trans.gif" />0&nbsp;&nbsp;<font class='color_connectable'>可连接：</font><b><font color="green">是</font></b> <font class='color_slots'>连接数：</font>无限制</span></td>
<td class="bottom" align="right"><span class="medium">当前时间：17:15<br />
<a href="messages.php"><img class="inboxnew" src="pic/trans.gif" alt="inbox" title="收件箱&nbsp;(有新短讯)" /></a> 10 (3 新) <a href="messages.php?action=viewmailbox&amp;box=-1"><img class="sentbox" alt="sentbox" title="发件箱" src="pic/trans.gif" /></a> 0 <a href="friends.php"><img class="buddylist" alt="Buddylist" title="社交名单" src="pic/trans.gif" /></a> <a href="getrss.php"><img class="rss" alt="RSS" title="获取RSS" src="pic/trans.gif" /></a>
</span></td>
</tr></table></td>
</tr></table>
</td></tr>
<tr><td id="outer" align="center" class="outer" style="padding-top: 20px; padding-bottom: 20px">
<div align="center" style="margin-bottom: 10px" id="ad_belownav"><a href="https://detail.tmall.com/item.htm?spm=a212k0.12153887.0.0.4d7c687d61dJCl&id=668093927311"><img src="/adv/jkjnas.jpg"></a></div><p><table border="0" cellspacing="0" cellpadding="10"><tr><td style='border: none; padding: 10px; background: red'>
<b><a href="messages.php"><font color="white">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;你有3条新短讯！点击查看&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></a></b></td></tr></table></p><br /><h1 style='margin:0px'><span class="nowrap"><b>seckiller</b><img class="warnedbig" src="pic/trans.gif" alt="Warned" style='margin-left: 4pt' /></span><img src="pic/flag/china.gif" alt="中国" style='margin-left: 8pt' /></h1><table class="main" width="940" border="0" cellspacing="0" cellpadding="0"><tr><td class="embedded"><h2>清除冗余种子，点击<a class="altlink" href="takeflush.php?id=97597">这里</a></h2>
<table width="100%" border="1" cellspacing="0" cellpadding="5">
<tr><td width="1%" class="rowhead nowrap" valign="top" align="right">邀请</td><td width="99%" class="rowfollow" valign="top" align="left"><a href="invite.php?id=97597" title="发送邀请">1</a></td></tr>
<tr><td width="1%" class="rowhead nowrap" valign="top" align="right">加入日期</td><td width="99%" class="rowfollow" valign="top" align="left">2022-05-01 10:41:27 (<span title="2022-05-01 10:41:27">1月19天前</span>)</td></tr>
<tr><td width="1%" class="rowhead nowrap" valign="top" align="right">最近动向</td><td width="99%" class="rowfollow" valign="top" align="left">2022-06-19 17:15:38 (<span title="2022-06-19 17:15:38">&lt; 1分前</span>)</td></tr>
<tr><td width="1%" class="rowhead nowrap" valign="top" align="right">当前IP</td><td width="99%" class="rowfollow" valign="top" align="left">240e:3a1:ecd:d250:4d80:4f48:1104:7d7a<span title="">[]</span></td></tr>
<tr><td width="1%" class="rowhead nowrap" valign="top" align="right">BT客户端</td><td width="99%" class="rowfollow" valign="top" align="left">Transmission/3.00 (240e:3a1:ecd:d250:48d3:24ff:fe13:6bd7:51413)</td></tr>
<tr><td width="1%" class="rowhead nowrap" valign="top" align="right">传输</td><td width="99%" class="rowfollow" valign="top" align="left"><table border="0" cellspacing="0" cellpadding="0"><tr><td class="embedded"><strong>分享率</strong>: <font color="">38.980</font></td><td class="embedded">&nbsp;&nbsp;<img src="pic/smilies/163.gif" alt="" /></td></tr><tr><td class="embedded"><strong>上传量</strong>: 10.636 TB</td><td class="embedded">&nbsp;&nbsp;<strong>下载量</strong>: 279.42 GB</td><td class="embedded">&nbsp;&nbsp;<strong>做种积分</strong>: 119133.6&nbsp;(注:做种积分自2020年1月1日零时开始统计)</td></tr></table></td></tr>
<tr><td width="1%" class="rowhead nowrap" valign="top" align="right">BT时间</td><td width="99%" class="rowfollow" valign="top" align="left"><table border="0" cellspacing="0" cellpadding="0"><tr><td class="embedded"><strong>做种/下载时间比率</strong>: <font color="">424.665</font></td><td class="embedded">&nbsp;&nbsp;<img src="pic/smilies/163.gif" alt="" /></td></tr><tr><td class="embedded"><strong>做种时间</strong>: 6964天16:48:39</td><td class="embedded">&nbsp;&nbsp;<strong>下载时间</strong>: 16天09:36:39</td></tr></table></td></tr>
<tr><td width="1%" class="rowhead nowrap" valign="top" align="right">性别</td><td width="99%" class="rowfollow" valign="top" align="left"><img class='male' src='pic/trans.gif' alt='Male' title='男生' style='margin-left: 4pt' /></td></tr>
<tr><td width="1%" class="rowhead nowrap" valign="top" align="right">等级</td><td width="99%" class="rowfollow" valign="top" align="left"><img alt="Power User" title="Power User" src="pic/power.gif" /> </td></tr>
<tr><td width="1%" class="rowhead nowrap" valign="top" align="right">种子评论</td><td width="99%" class="rowfollow" valign="top" align="left">0</td></tr>
<tr><td width="1%" class="rowhead nowrap" valign="top" align="right">论坛帖子</td><td width="99%" class="rowfollow" valign="top" align="left">0</td></tr>
<tr><td width="1%" class="rowhead nowrap" valign="top" align="right">魔力值</td><td width="99%" class="rowfollow" valign="top" align="left">120718.6</td></tr>
<tr><td width="1%" class="rowhead nowrap" valign="top" align="right">发布种子</td><td width="99%" class="rowfollow" valign="top" align="left"><a href="javascript: getusertorrentlistajax('97597', 'uploaded', 'ka'); klappe_news('a')"><img class="plus" src="pic/trans.gif" id="pica" alt="Show/Hide" title="显示/隐藏" /> <u>[显示/隐藏]</u></a><div id="ka" style="display: none;"></div></td></tr>
<tr><td width="1%" class="rowhead nowrap" valign="top" align="right">当前做种</td><td width="99%" class="rowfollow" valign="top" align="left"><a href="javascript: getusertorrentlistajax('97597', 'seeding', 'ka1'); klappe_news('a1')"><img class="plus" src="pic/trans.gif" id="pica1" alt="Show/Hide" title="显示/隐藏" /> <u>[显示/隐藏]</u></a><div id="ka1" style="display: none;"></div>&nbsp;&nbsp;(253个种子，共计15.973 TB)</td></tr>
<tr><td width="1%" class="rowhead nowrap" valign="top" align="right">当前下载</td><td width="99%" class="rowfollow" valign="top" align="left"><a href="javascript: getusertorrentlistajax('97597', 'leeching', 'ka2'); klappe_news('a2')"><img class="plus" src="pic/trans.gif" id="pica2" alt="Show/Hide" title="显示/隐藏" /> <u>[显示/隐藏]</u></a><div id="ka2" style="display: none;"></div></td></tr>
<tr><td width="1%" class="rowhead nowrap" valign="top" align="right">完成种子</td><td width="99%" class="rowfollow" valign="top" align="left"><a href="javascript: getusertorrentlistajax('97597', 'completed', 'ka3'); klappe_news('a3')"><img class="plus" src="pic/trans.gif" id="pica3" alt="Show/Hide" title="显示/隐藏" /> <u>[显示/隐藏]</u></a><div id="ka3" style="display: none;"></div>&nbsp;&nbsp;(61个种子，共计8.052 TB)</td></tr>
<tr><td width="1%" class="rowhead nowrap" valign="top" align="right">未完成种子</td><td width="99%" class="rowfollow" valign="top" align="left"><a href="javascript: getusertorrentlistajax('97597', 'incomplete', 'ka4'); klappe_news('a4')"><img class="plus" src="pic/trans.gif" id="pica4" alt="Show/Hide" title="显示/隐藏" /> <u>[显示/隐藏]</u></a><div id="ka4" style="display: none;"></div></td></tr>
<tr><td width="1%" class="rowhead nowrap" valign="top" align="right"><font class='color_bonus'>&nbsp;&nbsp;H&amp;R:</font></td><td width="99%" class="rowfollow" valign="top" align="left">0/<span style="color:#f00;font-weight: bold;">0</span></td></tr>
</table>
</td></tr></table>
</td></tr></table><div id="footer"><div style="margin-top: 10px; margin-bottom: 30px;" align="center"> (c) <a href="https://pt.btschool.club" target="_self">BTSCHOOL</a> 2012-2022 Powered by <a href="aboutnexus.php">NexusPHP</a><br /><br />[page created in <b> 0.208450 </b> sec with <b>17</b> db queries, <b>17</b> reads and <b>10</b> writes of memcached and <b>615.30 KB</b> ram]</div>
<div style="display: none;" id="lightbox" class="lightbox"></div><div style="display: none;" id="curtain" class="curtain"></div></div><script src="/cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js" data-cf-settings="4a7d0149efcf75f7d8c0936c-|49" defer=""></script></body></html>