# coding=utf-8
import os

import requests

os.environ['NASTOOL_CONFIG'] = "E:\\my_project\\nas-tools\\test\\config.yaml"

from pt.sites import Sites
import re
from lxml import etree
from rmt.media import Media


if __name__ == "__main__":
    media = Media()
    x = media.get_media_info("Le camion")
    pass
